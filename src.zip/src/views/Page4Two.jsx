import React from "react";
// import MoreContent from '../components/MoreContent';
import Contact from '../components/Contact';
import Footer from '../components/Footer';

const Page4Two = () => {
  return (
    <div>
      <main className="page-main">
        {/* <MoreContent /> */}
        <Contact />
        <Footer />
      </main>
    </div>
  );
};

export default Page4Two;