import React from "react";
import Port from '../components/Port';
// import Contact from '../components/Contact';
// mport Footer from '../components/Footer';

const Page4One = () => {
  return (
    <div>
      <main className="page-main">
        <Port />
      </main>
    </div>
  );
};

export default Page4One;