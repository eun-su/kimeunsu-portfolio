// src/pages/Page3.js
import React from 'react';
// import Header from '../components/Header';
import Footer from '../components/Footer';

function Page1() {
  return (
    <div>
      {/* <Header /> */}
      <main>
        <div>This is Page 1</div>
      </main>
      <Footer />
    </div>
  );
}

export default Page1;