// src/pages/Page3.js
import React from 'react';
// import Header from '../components/Header';
import Footer from '../components/Footer';

function Page3() {
  return (
    <div>
      {/* <Header /> */}
      <main>
        <div>This is Page 3</div>
      </main>
      <Footer />
    </div>
  );
}

export default Page3;